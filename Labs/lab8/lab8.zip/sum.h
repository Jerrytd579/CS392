/*******************************************************************************
* Name        : sum.h
* Author      : Andrew Chuah, Jerry Cheng
* Date        : 6/15/2020
* Description : lab8
* Pledge      : I pledge my honor that I have abided by the Stevens Honor System.
******************************************************************************/
#ifndef SUM_H_
#define SUM_H_

/* Function prototype */
int sum_array(int *array, const int length);

#endif
